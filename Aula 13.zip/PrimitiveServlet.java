import java.io.IOException;
import javax.servlet.*;

public class PrimitiveServlet implements Servlet {      
	public void init(ServletConfig config) throws ServletException {
		System.out.println("Init");
	}
	
	public void service(ServletRequest request, ServletResponse response) 
		throws ServletException, IOException {
		System.out.println("Service");
	}
	
	public void destroy() {
		System.out.println("Destroy");
	}

	public ServletConfig getServletConfig() {
		return null;
	}

	public String getServletInfo() {
		return null; 
	}	
}
