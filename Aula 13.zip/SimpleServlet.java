import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;

public class SimpleServlet extends GenericServlet {
	public void service(ServletRequest request, ServletResponse response) 
		throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>");
		out.println("Extending GenericServlet");
		out.println("</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<b>Extending GenericServlet makes your code simpler.</b>");
		out.println("</body>");
		out.println("</html>");
	}
}
