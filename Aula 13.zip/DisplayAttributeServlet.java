import java.io.IOException;
import java.util.Enumeration;
import javax.servlet.*;

public class DisplayAttributeServlet implements Servlet {
	ServletConfig servletConfig;
	public void init(ServletConfig config) throws ServletException {
		this.servletConfig = config;
	}
	public void service(ServletRequest request, ServletResponse response) 
		throws ServletException, IOException {
		ServletContext servletContext = this.getServletConfig().getServletContext();
		Enumeration attributes = servletContext.getAttributeNames();
		while (attributes.hasMoreElements()){
			String attribute = (String)attributes.nextElement();
			System.out.println("Attribute name:"+attribute);
			System.out.println("Attribute value:"+servletContext.getAttribute(attribute));			
		}	
	}
	public void destroy() {
	}
	public ServletConfig getServletConfig() {
		return servletConfig;
	}
	public String getServletInfo() {
		return null; 
	}
}
