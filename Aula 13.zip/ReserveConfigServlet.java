import javax.servlet.*;
import java.io.IOException;
import java.util.Enumeration;

public class ReserveConfigServlet implements Servlet {
	ServletConfig servletConfig;
	
	public void init(ServletConfig config) throws ServletException {
		this.servletConfig=config;
	}
	
	public void service(ServletRequest request, ServletResponse response) 
		throws ServletException, IOException {
		Enumeration parameters = this.getServletConfig().getInitParameterNames();
		while(parameters.hasMoreElements()){
			String parameter = (String) parameters.nextElement();
			System.out.println("Parameter name:" + parameter);
			System.out.println("Parameter value:" + this.getServletConfig().getInitParameter(parameter));			
		}
	}
	public void destroy() {	
	}	
	
	public ServletConfig getServletConfig() {
		return this.servletConfig;
	}

	public String getServletInfo() {
		return null;
	}
}
