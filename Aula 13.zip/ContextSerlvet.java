import java.io.IOException;
import java.util.Enumeration;
import javax.servlet.*;

public class ContextServlet implements Servlet {
    private ServletConfig config;
    public void init(ServletConfig config) throws ServletException {
        this.config = config;
    }
    public ServletConfig getServletConfig() {
        return config;
    }
    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
        ServletContext context = this.getServletConfig().getServletContext();
        Enumeration e = context.getInitParameterNames();
        while(e.hasMoreElements()){
            String parameter = (String) e.nextElement();
            System.out.println("Parameter:"+parameter);
            System.out.println("Value:"+context.getInitParameter(parameter));
        }
    }
    public String getServletInfo() {
        return null;
    }

    public void destroy() {
    }
}
