import java.io.IOException;
import java.util.Enumeration;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class ContextServeltAtributte implements Servlet {

    private ServletConfig config;
    public void init(ServletConfig config) throws ServletException {
        this.config = config;
    }

    public ServletConfig getServletConfig() {
        return this.config;
    }

    public void service(ServletRequest req, ServletResponse res) 
			throws ServletException, IOException {
        ServletContext context = this.getServletConfig().getServletContext();
        //Cria atributos na aplicação
        context.setAttribute("login","admin");
        context.setAttribute("pass","xxx");
        context.setAttribute("removeAttribute", "yyy");
        //Remove atributos na aplicação
        context.removeAttribute("removeAttribute");
        //Retorna todos os atributos da aplicação
        Enumeration e = context.getAttributeNames();
        while(e.hasMoreElements()){
            String attributte = (String) e.nextElement();
            String value = context.getAttribute(attributte).toString();
            System.out.println("Attribute: "+attributte);
            System.out.println("Value: "+value);
        }
        //Retorna o caminho da aplicação
        System.out.println("Path:"+context.getContextPath());
        //Retorna o caminho absoluto dado um caminho relativo.
        System.out.println("Real Path: "+context.getRealPath(context.getContextPath()));
        //Retorna a maior e menor versão que o container suporta.
        System.out.println("Major Version: "+context.getMajorVersion());
        System.out.println("Minor Version: "+context.getMinorVersion());       
        //Retona o nome do Servlet que foi definido na DD pela tag <display-name>
        System.out.println("Context Name: "+context.getServletContextName());
        //Escreve no log do servidor um registro.
        context.log("Arquivo x acessado com sucesso");
        //Retorna o Tipo MIME de um arquivo no servidor.
        System.out.println("Tipo MIME:"+context.getMimeType("editar.png"));
    }


    public String getServletInfo() {
        return "Autor: André Luis Schwerz";
    }

    public void destroy() {

    }
}

