import javax.servlet.*;
import java.io.IOException;
import java.util.Enumeration;

public class ConfigDemoServlet implements Servlet {
	public void init(ServletConfig config) throws ServletException {
		Enumeration parameters = config.getInitParameterNames();
		while(parameters.hasMoreElements()){
			String parameter = (String) parameters.nextElement();
			System.out.println("Parameter name:" + parameter);
			System.out.println("Parameter value:" + 
				config.getInitParameter(parameter));		
		}
	}
	public void service(ServletRequest request, ServletResponse response) 
		throws ServletException, IOException {	
	}
	
	public void destroy(){	
	}
	
	public String getServletInfo(){	
		return null;
	}
	
	public ServletConfig getServletConfig(){
		return null;
	}
}
