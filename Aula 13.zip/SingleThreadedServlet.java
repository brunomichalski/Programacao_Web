import java.io.*;
import javax.servlet.*;

public class SingleThreadedServlet extends GenericServlet{
	private static final long serialVersionUID = 1L;
	public synchronized void  service(ServletRequest request, ServletResponse response) 
		throws ServletException, IOException {
		int counter = 0;
		try{			
			FileReader fr = new FileReader("counter.txt");
			BufferedReader reader = new BufferedReader(fr);		
			counter = Integer.parseInt(reader.readLine());
			reader.close();
		}catch (Exception e){
		}
		counter++;
		System.out.println(counter);
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}	
		try{
			BufferedWriter write = new BufferedWriter(new FileWriter("counter.txt"));
			write.write(Integer.toString(counter));
			write.close();
		}catch (Exception e) {
		}
	}
}
