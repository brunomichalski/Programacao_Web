import java.io.IOException;
import javax.servlet.*;

public class AttributeSetterServlet implements Servlet {
	public void init(ServletConfig config) throws ServletException {
		ServletContext servletContext = config.getServletContext();
		servletContext.setAttribute("password", "dingdong");
	}
	public void service(ServletRequest request, ServletResponse response) 
		throws ServletException, IOException {
	}
	
	public void destroy() {
	}

	public ServletConfig getServletConfig() {
		return null;
	}

	public String getServletInfo() {
		return null; 
	}
}
