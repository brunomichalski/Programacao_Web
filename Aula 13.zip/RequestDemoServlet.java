import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class RegisterServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title> The Get Method </title>");
		out.println("</head>");
		out.println("<body>");
		out.println("The servlet has received a GET. Now, click the button below.");
		out.println("<form method=\"post\">");
		out.println("<input type=\"submit\" value=\"Submit\" />");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title> The Post Method </title>");
		out.println("</head>");
		out.println("<body>");
		out.println("The servlet has received a Post.Thank you!");
		out.println("</body>");
		out.println("</html>");
	}
}
